package org.example;

import org.example.model.Inventory;
import org.example.repository.InventoryRepository;
import org.example.views.VentanaProduct;
import org.example.views.VentanaWarehouse;
import org.example.views.utils.TableColor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class Ventana extends JFrame {
    private JMenuBar menuBar;
    private JMenuItem m1;
    private JMenuItem m2;
    private JPanel panel;
    private JScrollPane scrollPanel;
    private JTable table;
    private DefaultTableModel modelo;

    public Ventana() {
        modelo = new DefaultTableModel() {
            public Class<?> getColumnClass(int colum) {
                return String.class;
            }
        };
        table = new TableColor();
        table.setModel(modelo);

        modelo.addColumn("Product Name");
        modelo.addColumn("On Stock");
        modelo.addColumn("Sold");
        modelo.addColumn("Total");
        modelo.addColumn("Warehouse");

        table.setBounds(26, 26, 463, 332);
        /*Object[] nuevafila = {"Coke", "50", "50", "100", "Plant 1"};
        Object[] nuevafila1 = {"Sprite", "3", "42", "45", "Plant 2"};
        Object[] nuevafila2 = {"Dr. Pepper", "85", "5", "90", "Plant 3"};
        Object[] nuevafila3 = {"Canada Dry", "50", "45", "95", "Plant 2"};

        modelo.addRow(nuevafila);
        modelo.addRow(nuevafila1);
        modelo.addRow(nuevafila2);
        modelo.addRow(nuevafila3);*/
        try {
            List<Inventory> inventoryList = new InventoryRepository().getListInventory();
            inventoryList.forEach(ob->{
                Object[] nuevafila = {ob.getProductName(), ob.getOnStock(), ob.getSold(), ob.getTotal(), ob.getWarehouse()};
                modelo.addRow(nuevafila);
            });
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        scrollPanel.setViewportView(table);
        setContentPane(panel);
        setTitle("Inventory");
        setSize(450, 300);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        listenerActions();
    }

    private void listenerActions() {
        m1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VentanaWarehouse();
            }
        });
        m2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VentanaProduct();
            }
        });
    }

}
