package org.example.views;

import org.example.model.Inventory;
import org.example.model.Products;
import org.example.repository.InventoryRepository;
import org.example.repository.ProductsRepsitory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.util.List;

public class VentanaProduct extends JFrame {


    private JTextField nameText;
    private JTextField totalText;
    private JTextField remainingText;
    private JButton eliminarButton;
    private JButton editarButton;
    private JButton guardarButton;
    private JComboBox warehouseCombo;
    private JScrollPane scrollPanel;
    private JPanel panel1;
    private DefaultTableModel modelo;
    private ComboBoxModel modeloC;
    private JTable table;

    public VentanaProduct() {
        modelo = new DefaultTableModel() {
            public Class<?> getColumnClass(int colum) {
                switch (colum) {
                    case 0:
                        return Boolean.class;
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        return String.class;
                    default:
                        return Boolean.class;
                }
            }
        };
        table = new JTable();
        table.setModel(modelo);

        modelo.addColumn("Select");
        modelo.addColumn("Name");
        modelo.addColumn("Total Qty");
        modelo.addColumn("Remaining Qty");
        modelo.addColumn("Warehouse");

        table.setBounds(26, 26, 463, 332);
        /*Object[] nuevafila = {false,"Coke" ,"100" ,"50" ,"Plant 1"};
        Object[] nuevafila1 = {false,"Sprite" ,"45" ,"3" ,"Plant 2"};
        Object[] nuevafila2 = {false,"Dr. Pepper" ,"90" ,"85" ,"Plant 3"};

        modelo.addRow(nuevafila);
        modelo.addRow(nuevafila1);
        modelo.addRow(nuevafila2);*/
        try {
            List<Products> inventoryList = new ProductsRepsitory().getListPrroducts();
            inventoryList.forEach(ob -> {
                Object[] nuevafila = {ob.getName(), ob.getTotalQty(), ob.getRemainingQty(), ob.getWarehouse()};
                modelo.addRow(nuevafila);
            });
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        warehouseCombo.addItem("Plant 1");
        warehouseCombo.addItem("Plant 2");
        warehouseCombo.addItem("Plant 3");


        scrollPanel.setViewportView(table);
        eventos();
        setContentPane(panel1);
        setTitle("Products");
        setSize(450, 300);
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setVisible(true);
    }

    private void eventos() {
        eliminarButton.addActionListener(arg0 -> {
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {
                if (((Boolean) modelo.getValueAt(i, 0)) == true) {
                    try {
                        new ProductsRepsitory().delete((String) modelo.getValueAt(i, 1));
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        editarButton.addActionListener(arg0 -> {
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {
                if (table.getSelectionModel().isSelectedIndex(i)) {
                    nameText.setText((String) table.getValueAt(i, 1));
                    nameText.disable();
                    totalText.setText((String) table.getValueAt(i, 2));
                    remainingText.setText((String) table.getValueAt(i, 3));
                }
            }
        });
        guardarButton.addActionListener(arg0 -> {
            boolean ban = false;
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {

                if (table.getValueAt(i, 1).equals(nameText.getText())) {
                    table.setValueAt(totalText.getText(), i, 2);
                    table.setValueAt(remainingText.getText(), i, 3);
                    table.setValueAt(warehouseCombo.getItemAt(warehouseCombo.getSelectedIndex()), i, 4);
                    try {
                        ProductsRepsitory repsitory = new ProductsRepsitory();
                        Products products = new Products();
                        products.setTotalQty(totalText.getText());
                        products.setRemainingQty(remainingText.getText());
                        products.setWarehouse(totalText.getText());
                        products.setTotalQty((String) warehouseCombo.getItemAt(warehouseCombo.getSelectedIndex()));
                        repsitory.edit(products);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    limpiarCampos();
                    ban = true;
                }
            }

            Object[] nuevafila = {false, nameText.getText(), totalText.getText(), remainingText.getText(),
                    warehouseCombo.getItemAt(warehouseCombo.getSelectedIndex())};
            if (!ban) {
                modelo.addRow(nuevafila);
                ProductsRepsitory repsitory = null;
                try {
                    repsitory = new ProductsRepsitory();
                    Products products = new Products();
                    products.setTotalQty(totalText.getText());
                    products.setRemainingQty(remainingText.getText());
                    products.setWarehouse(totalText.getText());
                    products.setTotalQty((String) warehouseCombo.getItemAt(warehouseCombo.getSelectedIndex()));
                    repsitory.save(products);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }

        });
    }

    private void limpiarCampos() {
        nameText.setText("");
        totalText.setText("");
        remainingText.setText("");
        nameText.enable();
    }
}
