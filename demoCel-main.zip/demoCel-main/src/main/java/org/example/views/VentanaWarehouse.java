package org.example.views;

import org.example.model.Products;
import org.example.model.Warehouse;
import org.example.repository.ProductsRepsitory;
import org.example.repository.WarehouseRepository;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

public class VentanaWarehouse extends JFrame {
    private JPanel panel1;
    private JScrollPane scrollPanel;
    private JButton editarButton;
    private JButton eliminarButton;
    private JButton guardarButton;
    private JTextField min;
    private JTextField nameText;
    private JTextField max;
    private DefaultTableModel modelo;
    private JTable table;

    public VentanaWarehouse() {
        modelo = new DefaultTableModel() {
            public Class<?> getColumnClass(int colum) {
                switch (colum) {
                    case 0:
                        return Boolean.class;
                    case 1:
                    case 2:
                    case 3:
                        return String.class;
                    default:
                        return Boolean.class;
                }
            }
        };
        table = new JTable();
        table.setModel(modelo);

        modelo.addColumn("Select");
        modelo.addColumn("Name");
        modelo.addColumn("Min product");
        modelo.addColumn("Max product");

        table.setBounds(26, 26, 463, 332);
        Object[] nuevafila = {false, "Plant 1", "10", "100"};
        Object[] nuevafila1 = {false, "Plant 2", "5", "50"};
        Object[] nuevafila2 = {false, "Plant 3", "7", "75"};

        modelo.addRow(nuevafila);
        modelo.addRow(nuevafila1);
        modelo.addRow(nuevafila2);

        scrollPanel.setViewportView(table);
        eventos();
        setContentPane(panel1);
        setTitle("Warehouse");
        setSize(450, 300);
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setVisible(true);
    }

    private void eventos() {
        eliminarButton.addActionListener(arg0 -> {
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {
                if (((Boolean) modelo.getValueAt(i, 0)) == true) {
                    modelo.removeRow(i);
                    WarehouseRepository repsitory = null;
                    try {
                        repsitory = new WarehouseRepository();
                        repsitory.delete((String) modelo.getValueAt(i, 1));
                        repsitory.closeConnection();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        editarButton.addActionListener(arg0 -> {
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {
                if (table.getSelectionModel().isSelectedIndex(i)) {
                    nameText.setText((String) table.getValueAt(i, 1));
                    nameText.disable();
                    min.setText((String) table.getValueAt(i, 2));
                    max.setText((String) table.getValueAt(i, 3));
                }
            }
        });
        guardarButton.addActionListener(arg0 -> {
            boolean ban = false;
            for (int i = (table.getRowCount() - 1); i >= 0; i--) {

                if (table.getValueAt(i, 1).equals(nameText.getText())) {
                    table.setValueAt(min.getText(), i, 2);
                    table.setValueAt(max.getText(), i, 3);
                    WarehouseRepository repsitory = null;
                    try {
                        repsitory = new WarehouseRepository();
                        Warehouse warehouse = new Warehouse();
                        warehouse.setName(nameText.getText());
                        warehouse.setMinProduct(min.getText());
                        warehouse.setMaxProduct(max.getText());
                        repsitory.editWarehouse(warehouse);
                        repsitory.closeConnection();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    limpiarCampos();
                    ban = true;
                }
            }

            Object[] nuevafila = {false, nameText.getText(), min.getText(), max.getText()};
            if (!ban) {
                modelo.addRow(nuevafila);
                WarehouseRepository repsitory = null;
                try {
                    repsitory = new WarehouseRepository();
                    Warehouse warehouse = new Warehouse();
                    warehouse.setName(nameText.getText());
                    warehouse.setMinProduct(min.getText());
                    warehouse.setMaxProduct(max.getText());
                    repsitory.saveWarehouse(warehouse);
                    repsitory.closeConnection();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    private void limpiarCampos() {
        nameText.setText("");
        min.setText("");
        max.setText("");
        nameText.enable();
    }
}
