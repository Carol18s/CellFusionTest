package org.example.views.utils;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public class TableColor extends JTable {
    @Override
    public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
        Component component = super.prepareRenderer(renderer, row, column);
        if (getValueAt(row, column).getClass().equals(String.class)) {
            if(column == 1){
                int valor = Integer.valueOf((String) this.getValueAt(row, 1));
                int total = Integer.valueOf((String) this.getValueAt(row, 3));
                System.out.println(valor+" "+total);
                int totalPorcentaje = (100 * valor) / total;
                if (totalPorcentaje < 100 && totalPorcentaje > 66 && column == 1)
                    component.setBackground(Color.GREEN);
                if (totalPorcentaje < 67 && totalPorcentaje > 33 && column == 1)
                    component.setBackground(Color.YELLOW);
                if (totalPorcentaje < 34 && totalPorcentaje > 0 && column == 1)
                    component.setBackground(Color.RED);
                return component;
            }
            else {
                component.setBackground(Color.white);
            }

        }
        return component;
    }
}
