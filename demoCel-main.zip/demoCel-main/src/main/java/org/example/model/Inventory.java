package org.example.model;

public class Inventory {
    private String productName;
    private String onStock;
    private String sold;
    private String total;
    private String warehouse;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getOnStock() {
        return onStock;
    }

    public void setOnStock(String onStock) {
        this.onStock = onStock;
    }

    public String getSold() {
        return sold;
    }

    public void setSold(String sold) {
        this.sold = sold;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }
}
