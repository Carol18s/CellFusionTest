package org.example.model;

public class Warehouse {
    private String name;
    private String minProduct;
    private String maxProduct;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMinProduct() {
        return minProduct;
    }

    public void setMinProduct(String minProduct) {
        this.minProduct = minProduct;
    }

    public String getMaxProduct() {
        return maxProduct;
    }

    public void setMaxProduct(String maxProduct) {
        this.maxProduct = maxProduct;
    }
}
