package org.example.repository;

import org.example.model.Warehouse;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WarehouseRepository {
    Connection connection;

    public WarehouseRepository() throws SQLException {
        connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory",
                "root", "root");
    }

    public List<Warehouse> getListWarehouse() throws SQLException {
        PreparedStatement st = (PreparedStatement) connection
                .prepareStatement("Select * from WAREHOUSES");
        List<Warehouse> warehousesList = new ArrayList<>();
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Warehouse warehouse = new Warehouse();
            warehouse.setName(rs.getString("name"));
            warehouse.setMaxProduct(rs.getString("maxProduct"));
            warehouse.setMinProduct(rs.getString("minProduct"));
            warehousesList.add(warehouse);
        }
        rs.close();
        st.close();
        return warehousesList;
    }

    public void saveWarehouse(Warehouse warehouse) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("insert INTO WAREHOUSES values (?,?,?)");
        st.setString(1, warehouse.getName());
        st.setString(2, warehouse.getMinProduct());
        st.setString(3, warehouse.getMaxProduct());
        st.executeQuery();
        st.close();
    }

    public void editWarehouse(Warehouse warehouse) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("update WAREHOUSES set minProduct=?, maxProduct=? where name=?");
        st.setString(3, warehouse.getName());
        st.setString(1, warehouse.getMinProduct());
        st.setString(2, warehouse.getMaxProduct());
        st.executeUpdate();
        st.close();
    }

    public void delete(String name) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("delete * from WAREHOUSES where name = ?");
        st.setString(1, name);
        st.executeQuery();
        st.close();
    }

    public void closeConnection() throws SQLException {
        connection.close();
    }
}
