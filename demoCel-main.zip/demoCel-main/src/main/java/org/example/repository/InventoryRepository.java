package org.example.repository;


import org.example.model.Inventory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {
    Connection connection;

    public InventoryRepository() throws SQLException {
        connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory",
                "root", "root");
    }

    public List<Inventory> getListInventory() throws SQLException {
        PreparedStatement st = (PreparedStatement) connection
                .prepareStatement("Select * from WAREHOUSES");
        List<Inventory> warehousesList = new ArrayList<>();
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Inventory inventory = new Inventory();
            inventory.setProductName(rs.getString("productName"));
            inventory.setSold(rs.getString("sold"));
            inventory.setTotal(rs.getString("total"));
            inventory.setWarehouse(rs.getString("warehouse"));
            inventory.setOnStock(rs.getString("onStock"));
            warehousesList.add(inventory);
        }
        rs.close();
        st.close();
        return warehousesList;
    }

    public void save(Inventory inventory) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("insert INTO inventory values (?,?,?,?,?)");
        st.setString(1, inventory.getProductName());
        st.setString(2, inventory.getOnStock());
        st.setString(3, inventory.getSold());
        st.setString(4, inventory.getTotal());
        st.setString(5, inventory.getWarehouse());
        st.executeQuery();
        st.close();
    }

    public void edit(Inventory inventory) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("update inventory set productName = ?," +
                        "onStock=?," +
                        "sold=?," +
                        "total=?," +
                        "warehouse=? where productName=?");
        st.setString(1, inventory.getProductName());
        st.setString(2, inventory.getOnStock());
        st.setString(3, inventory.getSold());
        st.setString(4, inventory.getTotal());
        st.setString(5, inventory.getWarehouse());
        st.executeUpdate();
        st.close();
    }
    public void delete(String name) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("delete * from inventory where name = ?");
        st.setString(1,name);
        st.executeQuery();
        st.close();
    }

    public void closeConnection() throws SQLException {
        connection.close();
    }
}
