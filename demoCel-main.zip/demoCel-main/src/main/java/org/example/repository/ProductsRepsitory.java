package org.example.repository;

import org.example.model.Inventory;
import org.example.model.Products;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductsRepsitory {
    Connection connection;

    public ProductsRepsitory() throws SQLException {
        connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory",
                "root", "root");
    }
    public List<Products> getListPrroducts() throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("Select * from products");
        List<Products> productsList = new ArrayList<>();
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Products product = new Products();
            product.setName(rs.getString("name"));
            product.setRemainingQty(rs.getString("remainingQty"));
            product.setTotalQty(rs.getString("totalQty"));
            product.setWarehouse(rs.getString("warehouse"));
            productsList.add(product);
        }
        rs.close();
        st.close();
        return productsList;
    }

    public void save(Products products) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("insert INTO inventory values (?,?,?,?)");
        st.setString(1, products.getName());
        st.setString(2, products.getTotalQty());
        st.setString(3, products.getRemainingQty());
        st.setString(4, products.getWarehouse());
        st.executeQuery();
        st.close();
    }

    public void edit(Products products) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("update inventory set " +
                        "remainingQty=?," +
                        "totalQty=?," +
                        "warehouse=? " +
                        "where name=?");
        st.setString(4, products.getName());
        st.setString(1, products.getRemainingQty());
        st.setString(2, products.getTotalQty());
        st.setString(3, products.getWarehouse());
        st.executeUpdate();
        st.close();
    }
    public void delete(String name) throws SQLException {
        PreparedStatement st = connection
                .prepareStatement("delete * from prducts where name = ?");
        st.setString(1,name);
        st.executeQuery();
        st.close();
    }
}
